import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.*;
import org.junit.jupiter.api.Test;

/**
 *
 * @author alexloco
 */
public class ProvaCicleVidaActivitats {

    // A) Assertions

    @Test
    public void testAssertNotEquals() {
        // assertNotEquals verifica que dos objectes no siguin iguals.
        assertNotEquals(5, 10, "5 i 10 no haurien de ser iguals");
    }

    @Test
    public void testAssertTrue() {
        // assertTrue verifica que una condició sigui certa.
        assertTrue(3 < 5, "3 és menor que 5");
    }

    @Test
    public void testAssertFalse() {
        // assertFalse verifica que una condició sigui falsa.
        assertFalse(5 < 3, "5 no és menor que 3");
    }

    @Test
    public void testAssertNull() {
        // assertNull verifica que un objecte sigui nul.
        String str = null;
        assertNull(str, "L'objecte hauria de ser nul");
    }

    @Test
    public void testAssertNotNull() {
        // assertNotNull verifica que un objecte no sigui nul.
        String str = "JUnit";
        assertNotNull(str, "L'objecte no hauria de ser nul");
    }

    @Test
    public void testAssertSame() {
        // assertSame verifica que dos referències apuntin al mateix objecte.
        String str1 = "JUnit";
        String str2 = str1;
        assertSame(str1, str2, "Les referències haurien de ser les mateixes");
    }

    @Test
    public void testAssertNotSame() {
        // assertNotSame verifica que dues referències no apuntin al mateix objecte.
        String str1 = "JUnit";
        String str2 = new String("JUnit");
        assertNotSame(str1, str2, "Les referències no haurien de ser les mateixes");
    }

    @Test
    public void testAssertThrows() {
        // assertThrows verifica que un codi llança una excepció específica.
        assertThrows(ArithmeticException.class, () -> {
            int result = 1 / 0;
        }, "Una divisió per zero hauria de llançar ArithmeticException");
    }

    // B) Assumptions

    @Test
    public void testAssumeFalse() {
        // assumeFalse salta el test si la condició és falsa.
        assumeFalse(5 < 3, "Aquesta condició és falsa, així que el test es saltarà");
        // Aquest codi no s'executarà perquè l'assumpció és falsa
        System.out.println("Aquest missatge no es veurà");
    }

    @Test
    public void testAssumingThat() {
        // assumingThat executa el codi dins el bloc només si l'assumpció és certa.
        assumingThat(5 > 3, () -> {
            // Aquest codi només s'executarà si l'assumpció és certa
            assertTrue(5 > 3, "5 és efectivament major que 3");
        });
        // Aquest codi s'executarà independentment de l'assumpció
        assertTrue(1 < 2, "1 és menor que 2");
    }
}
